
#import <Foundation/Foundation.h>

@interface NSString(MD5)

- (NSString *)MD5;

@end